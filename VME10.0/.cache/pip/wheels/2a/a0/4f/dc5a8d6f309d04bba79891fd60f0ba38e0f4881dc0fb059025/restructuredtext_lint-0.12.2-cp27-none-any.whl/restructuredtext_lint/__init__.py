# Export lint functions
from restructuredtext_lint.lint import lint, lint_file
lint = lint
lint_file = lint_file
