.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
    :alt: License: AGPL-3

Test module
===========

This module was written to check the test of rst syntax.
This is a rst file without syntax error.

Pygments test

.. code-block:: python

    if True:
        pass
