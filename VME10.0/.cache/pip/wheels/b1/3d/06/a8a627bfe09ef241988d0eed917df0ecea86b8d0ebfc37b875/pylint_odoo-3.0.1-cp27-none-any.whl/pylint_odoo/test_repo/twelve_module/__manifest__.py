{
    'name': 'Twelve module for tests',
    'license': 'AGPL-3',
    'author': u'Jesus, Odoo Community Association (OCA)',
    'version': '12.0.1.0.0',
    'depends': [
        'base',
    ],
    'data': [
        'security/ir.model.access.csv',
    ],
}
