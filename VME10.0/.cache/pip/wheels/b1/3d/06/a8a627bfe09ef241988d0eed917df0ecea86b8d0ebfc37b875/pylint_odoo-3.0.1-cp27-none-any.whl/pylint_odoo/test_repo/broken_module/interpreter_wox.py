#!/usr/bin/python
# -*- coding: utf-8 -*-


"Module python with interpreter but without execute permission."
