Python Serial Port Extension for Win32, Linux, BSD, Jython, IronPython


