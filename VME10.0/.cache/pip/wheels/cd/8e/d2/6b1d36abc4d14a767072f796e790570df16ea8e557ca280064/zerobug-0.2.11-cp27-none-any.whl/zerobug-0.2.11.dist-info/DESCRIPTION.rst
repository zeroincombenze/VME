Zeroincombenze continuous testing framework and tools for python and bash programs.

Create and manage simply and easily Unit Test Enviroment.


