# -*- coding: utf-8 -*-
{
    'name': 'Broken module 2 for tests',
    'license': 'unknow license',  # unknow license
    'author': 'Other,Odoo Community Association (OCA)',  # Missing oca author
    'development_status': 'InvalidDevStatus',
    'website': 'https://odoo-community.org,https://odoo.com',
    'version': '1.0',
    'depends': ['base'],
    'data': [],
    'test': [],
    'installable': False,
}
