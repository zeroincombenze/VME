# -*- coding: utf-8 -*-


"Module python without interpreter but with execute permission."
