# coding: utf-8
try:
    import uninstalled_module
except ImportError:
    uninstalled_module = None
