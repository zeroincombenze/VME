from odoo import models


class TwelveModel(models.Model):
    _name = 'twelve.model'
