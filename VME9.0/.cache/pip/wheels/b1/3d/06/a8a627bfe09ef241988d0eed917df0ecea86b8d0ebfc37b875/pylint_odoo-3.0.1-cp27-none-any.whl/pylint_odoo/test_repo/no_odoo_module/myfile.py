# -*- coding: utf-8 -*-
import other_package

if __name__ == '__main__':
    var = other_package
