Crete consistent DB for test and/or
do massive operation on multiple Odoo databases.


