from . import clodoo as clodoo
from . import transodoo
from clodoocore import (extract_vals_from_rec,
                        cvt_from_ver_2_ver,
                        declare_mandatory_fields)
from clodoolib import (build_odoo_param,crypt)
