# -*- coding: utf-8 -*-
# Import file library
"""
Import Partner from CSV

This program supplies functions to import partner.
#
# Example of client software:
#
import csv
from import_partners import (init_n_connect, add_elem)
MYDICT_C = {
    'is_company': 0,
    'name': 1,
}
MYDICT_S = {
    'is_company': 0,
    'name': 1,
}
def main():
    odoo, uid, ctx = init_n_connect(flavour='myname')
    ctx['IN_country_id'] = 'name'
    dialect = 'excel'
    with open(ctx['csv_fn'], 'rbU') as f:
        hdr = False
        reader = csv.reader(f, dialect=dialect)
        for row in reader:
            if not hdr:
                hdr = True
                continue
            add_elem(row, ctx, MYDICT_C, MYDICT_S)


Parameters as key of ctx:
    default_XXX: value for field XXX if not in csv file
    TRX_XXX: borderline translation dictionary for field XXX (1)
    customers: import customers (from command line)
    company_name: company name to import data
    flavour: suffix to compose csv filename
    suppliers: import suppliers (from command line)
    IN_country_id: recognize country_id by 'code' or 'name'
    IN_state_id: recognize country_state_id by 'code' or 'name'

Field in csv files:
    is_company: True id field value not 'No' neither ''
    individual: True if field value not ''
    vat: country_iso_code added if missed

(1) Borderline Translation dictionary:
Some fields require to convert source value into local Odoo value.
To do automatic translation supply a dictionary in form:
TRX_XXX = {'original_value': 'Odoo_value', ...}
When field XXX in file csc contains value 'original_value' is written into
local Odoo DB as 'Odoo_value'.
"""
import sys
# import os
import time
import clodoo
import z0lib
# import pdb


__version__ = "0.2.0"


msg_time = time.time()


def msg_burst(text):
    global msg_time
    t = time.time() - msg_time
    if (t > 3):
        print text
        msg_time = time.time()


def get_company_id(ctx):
    model = 'res.company'
    company_name = ctx.get('company_name', 'La % Azienda')
    ids = clodoo.searchL8(ctx, model, [('name', 'ilike', company_name)])
    if not ids:
        ids = clodoo.searchL8(ctx, model, [('id', '>', 1)])
    if ids:
        value = ids[0]
    else:
        value = 1
    if 'default_company_id' not in ctx:
        ctx['default_company_id'] = value
    return value


def get_country_id(ctx, value):
    # country_code = False
    if value:
        model = 'res.country'
        if ctx.get('IN_country_id', '') == 'code':
            ids = clodoo.searchL8(ctx, model,
                                  [('code', '=', value.upper())])
        else:
            ids = clodoo.searchL8(ctx, model,
                                  [('name', 'ilike', value)])
        if ids:
            value = ids[0]
        if 'default_country_id' not in ctx:
            ctx['default_country_id'] = value
    return value


def get_state_id(ctx, field_name, value, country_id):
    if value:
        x = 'IN_%s' % field_name
        model = 'res.country.state'
        if x == 'code':
            ids = clodoo.searchL8(ctx, model,
                                  [('country_id', '=', country_id),
                                   ('code', '=', value.upper())])
        else:
            ids = clodoo.searchL8(ctx, model,
                                  [('country_id', '=', country_id),
                                   ('name', 'ilike', value)])
        if ids:
            value = ids[0]
    return value


def cvt_val(ctx, field_name, value):
    def_field_name = 'default_%s' % field_name
    trx_field_name = 'TRX_%s' % field_name
    if value:
        if trx_field_name in ctx:
            trx_dict = ctx[trx_field_name]
            if value in trx_dict:
                value = trx_dict[value]
            elif '$BOOLEAN' in trx_dict:
                if value.lower() == 'no' or \
                        value == '0' or \
                        value.lower() == 'false':
                    value = False
                else:
                    value = True
            else:
                value = value.strip()
        if field_name == 'company_id':
            value = get_company_id(ctx)
        elif field_name == 'country_id':
            value = get_country_id(ctx, value)
        else:
            value = value.strip()
    elif def_field_name in ctx:
        value = ctx[def_field_name]
    elif trx_field_name in ctx:
        trx_dict = ctx[trx_field_name]
        if '$BOOLEAN' in trx_dict:
            value = False
    elif field_name == 'company_id':
        value = get_company_id(ctx)
    return value


def write_log(msg):
    fd = open('./import_partners.log', 'a')
    fd.write('%s\n' % msg)
    fd.close()
    print msg


def add_elem(row, ctx, MYDICT_C, MYDICT_S):
    def add_val(row, ctx, MYDICT, field_name):
        def_field_name = 'default_%s' % field_name
        if field_name in MYDICT:
            idx = MYDICT[field_name]
            if idx >= len(row):
                print 'Invalid translation field %d' % idx
                # continue
            vals[field_name] = cvt_val(ctx, field_name, row[idx])
            # if field_name == 'state_id':
            #     if row[idx]:
            #         state_id = row[idx]
        elif def_field_name in ctx:
            vals[field_name] = ctx[def_field_name]

    if ctx['customers']:
        MYDICT = MYDICT_C
    else:
        MYDICT = MYDICT_S
    msg_burst('Reading %s ...' % row[MYDICT['name']])
    ids = clodoo.searchL8(ctx, 'res.country',
                          [('code', '=', 'IT')])
    if ids:
        country_IT = ids[0]
    model = 'res.partner'
    vals = {}
    country_code = False
    state_id = False
    for field_id in clodoo.searchL8(ctx, 'ir.model.fields',
                                    [('model', '=', model)]):
        field_name = clodoo.browseL8(ctx, 'ir.model.fields', field_id).name
        add_val(row, ctx, MYDICT, field_name)

    if 'is_company' not in vals:
        vals['is_company'] = True
    if 'name' not in vals:
        vals['name'] = 'UNKNOWN'
    elif 'name2' in MYDICT:
        vals['name'] = '%s %s' % (vals['name'], row[MYDICT['name2']])
        vals['name'] = vals['name'].strip()
    if 'company_id' not in vals:
        vals['company_id'] = get_company_id(ctx)
    if 'country_id' not in vals:
        vals['country_id'] = country_IT
        country_code = 'IT'
    if state_id:
        if ctx.get('IN_state_id') == 'code':
            ids = clodoo.searchL8(ctx, 'res.country.state',
                                  [('country_id', '=', vals['country_id']),
                                   ('code', '=', state_id.upper())])
        else:
            ids = clodoo.searchL8(ctx, 'res.country.state',
                                  [('country_id', '=', vals['country_id']),
                                   ('name', 'ilike', state_id)])
        if ids:
            vals['state_id'] = ids[0]
    if vals.get('vat'):
        if country_code and country_code != vals['vat'][0:2]:
            if country_code == 'IT' and vals['vat'].isdigit():
                vals['vat'] = 'IT%011d' % int(vals['vat'])
            else:
                vals['vat'] = country_code + vals['vat']

    if country_code in ('AT', 'BE', 'BG', 'CY', 'HR', 'DK',
                        'EE', 'FI', 'FR', 'DE', 'GB', 'EL', 'IE',
                        'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT',
                        'CZ', 'SK', 'RO', 'SI', 'ES', 'SE', 'HU'):
        fiscal = 'Regime%UE'
    elif country_code and country_code != 'IT':
        fiscal = 'Extra%UE'
    else:
        fiscal = 'Italia'
    ids = clodoo.searchL8(ctx, 'account.fiscal.position',
                          [('company_id', '=', vals['company_id']),
                           ('name', 'ilike', fiscal)])
    if ids:
        vals['propert_account_position'] = ids[0]

    ids = []
    if vals.get('old_customer_id'):
        ids = clodoo.searchL8(ctx, model, [('old_customer_id',
                                            '=',
                                            vals['old_customer_id'])])
    if not ids and vals.get('old_supplier_id'):
        ids = clodoo.searchL8(ctx, model, [('old_supplier_id',
                                            '=',
                                            vals['old_supplier_id'])])
    if not ids and vals.get('vat'):
        ids = clodoo.searchL8(ctx, model, [('vat', '=', vals['vat'])])
    if not ids:
        ids = clodoo.searchL8(ctx, model, [('name', '=', vals['name'])])
    if not ids:
        vals['customer'] = False
        vals['supplier'] = False
    if ctx['customers']:
        vals['customer'] = True
    if ctx['suppliers']:
        vals['supplier'] = True
    if ids:
        partner_id = ids[0]
        try:
            clodoo.writeL8(ctx, model, [partner_id], vals)
        except BaseException:
            write_log("Cannot import %s" % vals['name'])
            if vals.get('vat'):
                del vals['vat']
            try:
                clodoo.writeL8(ctx, model, [partner_id], vals)
            except BaseException:
                pass
    else:
        try:
            partner_id = clodoo.createL8(ctx, model, vals)
        except BaseException:
            write_log("Cannot create %s" % vals['name'])
            if vals.get('vat'):
                del vals['vat']
            try:
                partner_id = clodoo.createL8(ctx, model, vals)
            except BaseException:
                pass


def init_n_connect(flavour=None):
    title = 'Import partners %s' % flavour or ''
    parser = z0lib.parseoptargs(title,
                                "© 2017-2018 by SHS-AV s.r.l.",
                                version=__version__)
    parser.add_argument('-h')
    parser.add_argument("-c", "--config",
                        help="configuration command file",
                        dest="conf_fn",
                        metavar="file",
                        default='./import_partners.conf')
    parser.add_argument("-d", "--dbname",
                        help="DB name",
                        dest="db_name",
                        metavar="file",
                        default='demo8')
    parser.add_argument("-e", "--customer",
                        help="Import customers",
                        action="store_true",
                        dest="customers",
                        default=False)
    parser.add_argument("-f", "--filename",
                        help="Filename to import",
                        dest="csv_fn",
                        metavar="file",
                        default=False)
    parser.add_argument('-n')
    parser.add_argument('-q')
    parser.add_argument("-s", "--supplier",
                        help="Import suppliers",
                        action="store_true",
                        dest="suppliers",
                        default=False)
    parser.add_argument('-V')
    parser.add_argument('-v')
    # Connect to DB
    ctx = parser.parseoptargs(sys.argv[1:], apply_conf=False)
    ctx['flavour'] = flavour
    if not ctx['customers'] and not ctx['suppliers']:
        print "You must select customers and/or supplier"
        sys.exit(1)
    if not ctx['csv_fn']:
        if flavour:
            sfx = '_'
        else:
            sfx = ''
        if ctx['customers']:
            ctx['csv_fn'] = 'customers%s%s.csv' % (sfx, flavour or '')
        else:
            ctx['csv_fn'] = 'suppliers%s%s.csv' % (sfx, flavour or '')
    oerp, uid, ctx = clodoo.oerp_set_env(confn=ctx['conf_fn'],
                                         db=ctx['db_name'],
                                         ctx=ctx)
    ctx['TRX_country_id'] = {'inghilterra': 'Regno Unito',
                             'Inghilterra': 'Regno Unito'}
    ctx['TRX_is_company'] = {'$BOOLEAN': '', }
    ctx['TRX_individual'] = {'$BOOLEAN': '', }
    ctx['default_country_id'] = get_country_id(ctx, 'Italia')
    ctx['default_is_company'] = True
    return oerp, uid, ctx
