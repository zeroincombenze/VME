from setuptools import setup

setup(name='clodoo',
      version='',
      description='',
      classifiers=[
          'Development Status :: 1 - Planning',
      ])
