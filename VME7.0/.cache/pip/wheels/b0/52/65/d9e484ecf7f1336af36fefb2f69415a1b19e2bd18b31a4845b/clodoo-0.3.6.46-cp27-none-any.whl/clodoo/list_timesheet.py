#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import datetime
import math
import clodoo
from z0lib import parseoptargs
# import pdb


__version__ = "0.3.0"


parser = parseoptargs("Odoo test environment",
                      "© 2017-2018 by SHS-AV s.r.l.",
                      version=__version__)
parser.add_argument('-h')
parser.add_argument("-c", "--config",
                    help="configuration command file",
                    dest="conf_fn",
                    metavar="file",
                    default='./inv2draft_n_restore.conf')
parser.add_argument("-d", "--dbname",
                    help="DB name to connect",
                    dest="db_name",
                    metavar="file",
                    default='')
parser.add_argument("-f", "--from",
                    help="Date to start",
                    dest="start_date",
                    metavar="date",
                    default='')
parser.add_argument('-n')
parser.add_argument('-q')
parser.add_argument("-t", "--to",
                    help="Date to stop",
                    dest="stop_date",
                    metavar="date",
                    default='')
parser.add_argument('-V')
parser.add_argument('-v')
ctx = parser.parseoptargs(sys.argv[1:], apply_conf=False)
uid, ctx = clodoo.oerp_set_env(confn=ctx['conf_fn'],
                               db=ctx['db_name'],
                               ctx=ctx)

if not ctx['start_date']:
    month = datetime.datetime.now().month - 1
    start_date = '%04d-%02d-01' % (datetime.datetime.now().year, month)
else:
    start_date = ctx['start_date']
if not ctx['stop_date']:
    stop_date = '%04d-%02d-%02d' % (datetime.datetime.now().year,
                                    datetime.datetime.now().month,
                                    datetime.datetime.now().day)
else:
    stop_date = ctx['stop_date']
print 'Reading from %s to %s ' % (start_date, stop_date)
model = 'hr.analytic.timesheet'
ids = clodoo.searchL8(ctx, model, [('date', '>=', start_date),
                                   ('date', '<=', stop_date)], order='date')
WD = ['Lu', 'Ma', 'Me', 'Gi', 'Ve', 'Sa', 'Do']
dates = {}
date_list = []
for id in ids:
    hrt = clodoo.browseL8(ctx, model, id)
    if hrt.date not in dates:
        date_list.append(hrt.date)
        dates[hrt.date] = 0.0
    dates[hrt.date] += hrt.unit_amount
for dt in date_list:
    frac, whole = math.modf(dates[dt])
    mm = int(frac * 60)
    hh = int(whole)
    print '%s %s %02d:%02d' % (WD[dt.weekday()], dt, hh, mm)
