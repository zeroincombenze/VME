#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
# import os
# import time
import platform
import clodoo
# import clodoocore
# import clodoolib
import z0lib
# import pdb


__version__ = "0.2.0"

parser = z0lib.parseoptargs("Create an  Odoo sale.order example",
                            "© 2017-2018 by SHS-AV s.r.l.",
                            version=__version__)
parser.add_argument('-h')
parser.add_argument("-c", "--config",
                    help="configuration command file",
                    dest="conf_fn",
                    metavar="file",
                    default='./example.conf')
parser.add_argument("-d", "--dbname",
                    help="DB name to connect",
                    dest="db_name",
                    metavar="file",
                    default='')
parser.add_argument('-n')
parser.add_argument('-q')
parser.add_argument('-V')
parser.add_argument('-v')

UPDATE = True
# Connect to DB
print "Connect to DB"
ctx = parser.parseoptargs(sys.argv[1:], apply_conf=False)
oerp, uid, ctx = clodoo.oerp_set_env(confn=ctx['conf_fn'],
                                     db=ctx['db_name'],
                                     ctx=ctx)
# Recognize environment
hostname = platform.node()
if hostname[0:3] == 'shs':
    PRODUCT_TMPL_ID = 197
    PRODUCT_ID = 200
    model = 'res.company'
    company_id = oerp.search(model, [('name', 'ilike', 'La Tua Azienda')])[0]
else:
    PRODUCT_TMPL_ID = 2
    PRODUCT_ID = 2
    company_id = 1
model = 'stock.warehouse'
warehouse_id = oerp.search(model, [('company_id', '=', company_id)])[0]
model = 'res.partner'
partner_id = oerp.search(model, [('name', 'ilike', 'Nicola Bee'),
                                 ('is_company', '=', True)])[0]
shipping_id = oerp.search(model, [('name', 'ilike', 'Nicola Bee'),
                                  ('type', '=', 'delivery')])[0]
model = 'product.template'
product_tmpl_id = oerp.search(model, [('default_code', '=', 'vg7')])[0]
if not product_tmpl_id:
    product_tmpl_id = oerp.search(model,
                                  [('name', 'ilike', 'prodotto/generico')])[0]
if not product_tmpl_id:
    product_tmpl_id = oerp.search(model, [('name', 'ilike', 'test')])[0]
if not product_tmpl_id:
    product_tmpl_id = PRODUCT_TMPL_ID
model = 'product.product'
product_id = oerp.search(model, [('product_tmpl_id', '=', product_tmpl_id)])[0]
if not product_id:
    product_id = PRODUCT_ID
model = 'account.tax'
tax_ids = oerp.search(model, [('description', '=', '22v'),
                              ('company_id', '=', company_id)])
#
QTY_INV = 1
QTY_SELL = 15
PRC_TOTAL = 123.40
PRC_UNIT = PRC_TOTAL / QTY_SELL
#
print "Search for last order number ..."
model = 'sale.order'
model_line = 'sale.order.line'
i_last_numb = 1
i_last_line = 0
order1_id = 0
order2_id = 0
ids = oerp.search(model, [('name', 'like', 'order'),
                          ('state', '!=', 'cancel'),
                          ('company_id', '=', company_id)])
if ids:
    for id in ids:
        order = oerp.browse(model, id)
        name = order.name.split('-')
        number = int(name[0][5:])
        if len(name) > 1:
            try:
                linum = int(name[1][4:])
            except BaseException:
                linum = 0
        else:
            linum = 0
        if number >= i_last_numb:
            i_last_numb = number
        #     if number == i_last_numb and linum > i_last_line:
        #         i_last_line = linum
    i_last_numb += 1
    i_last_line += 1

order_info = {
    'company_id': company_id,
    'partner_id': partner_id,
    'partner_shipping_id': shipping_id,
    'warehouse_id': warehouse_id,
    'user_id': uid,
}

if not order1_id:
    ##################################################################
    # Creazione 1.mo preventivo "order%d-line%d, id=order1_id
    ##################################################################
    order_number = 'order%d-line%d' % (i_last_numb, i_last_line)
    order_info['name'] = order_number
    print "Create order %s ..." % order_number
    order1_id = oerp.create(model, order_info)


line_info = {
    'product_tmpl_id': product_tmpl_id,
    'product_id': product_id,
    'name': 'Prodotto specifico N.%d\n'
            '%d pz * %10.5f EUR' % (i_last_numb,
                                    QTY_SELL,
                                    PRC_UNIT),
    'company_id': company_id,
    'price_unit': PRC_TOTAL,
    'product_uom_qty': QTY_INV,
    'product_uos_qty': QTY_SELL,
    'tax_id': [(6, 0, tax_ids)],
}

ids = oerp.search(model_line, [('order_id', '=', order1_id)])
if not ids:
    print "Create line ..."
    line_info['order_id'] = order1_id
    line1_id = oerp.create(model_line, line_info)
else:
    line1_id = ids[0]

if not order2_id:
    ##################################################################
    # Creazione 2.do preventivo "order%d-line%d, id=order2_id
    ##################################################################
    i_last_line += 1
    order_number = 'order%d-line%d' % (i_last_numb, i_last_line)
    order_info['name'] = order_number
    print "Create 2.nd line (order %s)..." % order_number
    order2_id = oerp.create(model, order_info)

QTY_INV = 1
QTY_SELL = 29
PRC_TOTAL = 234.50
PRC_UNIT = PRC_TOTAL / QTY_SELL
line_info['name'] = 'Prodotto specifico N.%d\n%d pz * %10.5f EUR' % (
    i_last_numb, QTY_SELL, PRC_UNIT)
line_info['price_unit'] = PRC_TOTAL
line_info['product_uom_qty'] = QTY_INV
line_info['product_uos_qty'] = QTY_SELL
model_line = 'sale.order.line'
ids = oerp.search(model_line, [('order_id', '=', order2_id)])
if not ids:
    print "Create line ..."
    line_info['order_id'] = order2_id
    line2_id = oerp.create(model_line, line_info)
    raw_input('See 2 quotations and press RET to continue')
else:
    line2_id = ids[0]
    if 'order_id' in line_info:
        del line_info['order_id']
    order = oerp.browse(model, order2_id)
    if order.state == 'draft':
        oerp.write(model_line, [line2_id], line_info)

print "Confirm line 1"
# Read quotation number
order = oerp.browse(model, order1_id)
if order.state == 'draft':
    order_number = order.name.split('-')
    #################################################################
    # Cambio numero di prevntivo 1 (rimuvo numero riga) id=order1_id
    #################################################################
    # Rewrite 1.st quotation number without line-number
    oerp.write(model, [order1_id], {'name': order_number[0]})
    #################################################################
    # Workflow per trasformare preventivo 1 in ordine
    #################################################################
    oerp.exec_workflow(model,
                       'order_confirm',
                       order1_id)
    raw_input('See 1 quotation and 1 sale order, then press RET to continue')

print "Confirm line 2"
order = oerp.browse(model, order2_id)
if order.state == 'draft':
    #################################################################
    # Workflow per trasformare preventivo 2 in ordine (senza cambio numero)
    #################################################################
    # 2.nd line holds line number because will be merged
    oerp.exec_workflow(model,
                       'order_confirm',
                       order2_id)
    raw_input('See 2 sale orders, then press RET to continue')

# pdb.set_trace()
#################################################################
# Marco ordine 1 come destinatario del merge
#################################################################
# oerp.execute(model,
#              'button_merge',
#              order1_id)
# merge_ids = oerp.search(model, [('sale_order', '=', order1_id)])
# if len(merge_ids):
#     merge_id = max(merge_ids)
#     oerp.execute(model,
#                  'merge',
#                  merge_id)
model = 'sale.order.merge'
merge_id = oerp.create(model, {'sale_order': order1_id,
                               'to_merge': [(6, 0, [order2_id])]})
oerp.execute(model,
             'merge',
             merge_id)
print "Ended"
