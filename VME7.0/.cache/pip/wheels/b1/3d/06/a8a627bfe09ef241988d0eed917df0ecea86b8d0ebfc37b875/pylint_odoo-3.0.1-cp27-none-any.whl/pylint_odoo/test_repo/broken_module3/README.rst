Test module 3
=============

This module was written to check the test lint
