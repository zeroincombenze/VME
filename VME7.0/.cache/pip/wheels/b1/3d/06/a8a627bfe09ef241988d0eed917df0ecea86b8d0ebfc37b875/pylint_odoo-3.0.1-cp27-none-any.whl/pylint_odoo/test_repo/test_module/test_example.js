$(document).ready(function () {
    $('.example').each(function () {
        var oe_website_sale = this;
    });
});
