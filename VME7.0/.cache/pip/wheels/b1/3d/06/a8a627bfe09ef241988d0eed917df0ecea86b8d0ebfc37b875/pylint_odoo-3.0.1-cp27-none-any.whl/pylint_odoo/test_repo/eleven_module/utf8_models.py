# coding: utf-8

from odoo import models


class EleveModel(models.Model):
    _name = 'eleve.model'
