# -*- coding: utf-8 -*-
# !/usr/bin/python

"Module python with interpreter and execute permission."
