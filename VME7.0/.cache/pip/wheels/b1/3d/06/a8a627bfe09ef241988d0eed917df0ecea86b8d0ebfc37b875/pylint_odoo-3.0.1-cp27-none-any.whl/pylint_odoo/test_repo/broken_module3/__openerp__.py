# -*- coding: utf-8 -*-
{
    'name': 'Broken module 3 for tests',
    'license': 'AGPL-3',
    'author': ['Other', 'Odoo Community Association (OCA)'],  # expected string
    'website': 'htt://odoo-community.com',
    'version': '8.0.1.0.0foo',
    'depends': ['base'],
    'data': [],
    'test': [],
    'installable': False,
}
