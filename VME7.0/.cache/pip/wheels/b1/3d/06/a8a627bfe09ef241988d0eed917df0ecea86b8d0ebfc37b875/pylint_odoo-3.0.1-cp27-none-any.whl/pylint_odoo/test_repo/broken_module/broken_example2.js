/*Use of "+function" instead of "Number(function" */
+function ($) {
  'use strict';
  var var_1 = "value1";
  var var_2 = "value2";
};
/* Newline required at end of file but not found */