Documentation at https://github.com/markfinger/optional-django


