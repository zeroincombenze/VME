Documentation at https://github.com/markfinger/python-npm


