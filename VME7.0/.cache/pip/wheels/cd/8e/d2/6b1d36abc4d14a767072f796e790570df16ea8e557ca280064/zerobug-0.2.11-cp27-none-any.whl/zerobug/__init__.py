from . import z0testlib

Z0test = z0testlib.Z0test()
Z0BUG = z0testlib.Z0test()
