from setuptools import setup

setup(name='zerobug',
      version='0.2.7',
      description='Testing framework and tools for python and bash programs',
      classifiers=[
          'Development Status :: 1 - Planning',
      ])
