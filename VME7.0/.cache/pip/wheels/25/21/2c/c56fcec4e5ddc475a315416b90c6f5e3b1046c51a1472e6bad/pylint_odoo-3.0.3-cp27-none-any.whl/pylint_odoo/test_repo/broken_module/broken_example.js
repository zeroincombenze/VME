$(document).ready(function () {
    $('.example').each(function () {
        var oe_website_sale = this;
    }) /*missing semicolon*/
    /*Use of console log*/
    console.log("This is similar to a print");
}) /*missing semicolon*/
